#define MAXVEX 10
#define PORTA "21595" 
#define PORTB "22595"
#define AWSPORT "24595"   //aws TCP port
#define UDPPORT "23595"     //UDP port
#define MAXBUFLEN 100
#define HOST "localhost"
#define CLIENTPORT "25595"  //TCP port
#define BACKLOG 10

